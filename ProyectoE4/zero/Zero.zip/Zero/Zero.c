#include <18F2550.h>
#device adc=10
#FUSES HSPLL,NOWDT,NOPROTECT,NOLVP,NOPUT,NODEBUG,USBDIV,PLL5,CPUDIV2,VREGEN,MCLR
#use delay(clock=32MHz)
#use rs232(baud=9600,parity=N,xmit=PIN_C6,rcv=PIN_C7,bits=8)
#use fast_io(b)

int1 ID;
unsigned int16 Tau;

#INT_EXT
Handler()
{
   output_low(PIN_B7);
   delay_us(8000 - Tau);
   output_high(PIN_B7);
   if(Tau==0){ID=0;}
   if(Tau==8000){ID=1;}
   if(ID==0){Tau++;}
   else {Tau--;}
}
void main()
{
   Tau=0;
   set_tris_b(0x01);
   output_low(PIN_B7);
   setup_timer_1(T1_INTERNAL|T1_DIV_BY_2);
   enable_interrupts(INT_EXT);
   ext_int_edge(L_TO_H);
   enable_interrupts(GLOBAL);
   while(TRUE){}                          //Bucle infinito de espera.
}
